# Overview

This directory contains project files to build the AudioMark benchmark as a
library that can be linked to basic project, after it has been ported.

The two entry points are `ee_audiomark_init()` and `ee_audiomark_run()`.
