/* Custom OS support overrides for baremetal build */
#ifndef OS_SUPPORT_CUSTOM_H
#define OS_SUPPORT_CUSTOM_H

#include "kprintf.h"

/* Provide replacements for speex error/warning/notify handlers that don't
   pull in stdio or libc's exit(). */
#define OVERRIDE_SPEEX_FATAL
static inline void _speex_fatal(const char *str, const char *file, int line)
{
    kprintf("Fatal (internal) error in %s, line %d: %s\n", file, line, str);
    for(;;);
}

#define OVERRIDE_SPEEX_WARNING
static inline void speex_warning(const char *str)
{
    kprintf("warning: %s\n", str);
}

#define OVERRIDE_SPEEX_WARNING_INT
static inline void speex_warning_int(const char *str, int val)
{
    kprintf("warning: %s %d\n", str, val);
}

#define OVERRIDE_SPEEX_NOTIFY
static inline void speex_notify(const char *str)
{
    kprintf("notification: %s\n", str);
}

#define OVERRIDE_SPEEX_PUTC
static inline void _speex_putc(int ch, void *file)
{
    (void)file;
    kputc(ch);
}

#endif
